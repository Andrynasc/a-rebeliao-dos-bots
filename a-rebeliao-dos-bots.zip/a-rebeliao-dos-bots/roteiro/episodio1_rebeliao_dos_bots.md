# Episódio 1 — Do zero ao código

🎙️ PODCAST: A REBELIÃO DOS BOTS – Episódio 1: “Do zero ao código”

E aí, galera tech! 
Sejam bem‑vindos ao A Rebelião dos Bots, o podcast onde a gente descomplica o mundo da tecnologia sem precisar fazer “ctrl + alt + del” na sua cabeça.
Aqui, a ideia é te ajudar a entender esse universo cheio de códigos, telas e café — muito café! 
Então, se você sempre quis entender o que acontece por trás de um site ou app, fica por aqui, porque hoje o papo tá bugadamente bom!
Sabia que o primeiro “programador” do mundo foi, na real, uma programadora?
Pois é! Lá no século 19, uma mulher chamada Ada Lovelace ajudou a criar o que seria o primeiro algoritmo da história, muito antes dos computadores existirem de verdade.
Ela imaginou que uma máquina poderia pensar e executar tarefas — o que, convenhamos, é basicamente o que nossos computadores e bots fazem hoje.
Ou seja, a revolução digital começou com uma mente curiosa e um monte de imaginação. 
E falando em código… você sabe qual é a linguagem de programação mais usada no mundo hoje?
A resposta é JavaScript!
Ela é tipo o idioma universal da web — tá presente em praticamente todos os sites que você visita.
Com JavaScript, dá pra criar desde animações simples até sistemas inteiros, tipo o que o YouTube e o Instagram usam.
E o melhor: é uma das linguagens mais amigáveis pra quem tá começando.
Ou seja, se você quer entrar no mundo do front‑end, o JavaScript pode ser o seu passaporte digital! 🚀
E é isso, meus queridos rebeldes do código! 
Se curtiu o papo, já prepara o fone e vem comigo no próximo episódio, porque a revolução digital tá só começando.
Lembra: todo dev já foi iniciante um dia — o importante é começar a digitar! 
Eu sou [nome a definir] e esse foi o nosso episódio de A Rebelião dos Bots dessa semana.
Até o próximo “deploy”!
